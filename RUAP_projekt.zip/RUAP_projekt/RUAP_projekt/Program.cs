using System;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CallRequestResponseService
{
    class Program
    {
        static void Main(string[] args)
        {
            InvokeRequestResponseService().Wait();

        }

        static async Task InvokeRequestResponseService()
        {
            var handler = new HttpClientHandler()
            {
                ClientCertificateOptions = ClientCertificateOption.Manual,
                ServerCertificateCustomValidationCallback =
                        (httpRequestMessage, cert, cetChain, policyErrors) => { return true; }
            };
            using (var client = new HttpClient(handler))
            {
                string imgPath = "/home/ip/Desktop/1.png";

                // Convert image to Base64
                byte[] imageBytes = File.ReadAllBytes(imgPath);
                string base64Image = Convert.ToBase64String(imageBytes);

                // Construct the JSON request body
                var requestBody = $@"
                {{
                    ""Inputs"": {{
                    ""WebServiceInput0"": [
                    {{
                    ""image"": ""{base64Image}"",
                    ""id"": 6,""category"": ""cap""
                    }}]}},
                    ""GlobalParameters"": {{}}
                }}";

                // Replace with your API key
                const string apiKey = "SLgwCGTO1bNo88EI4ytYofAj7pN1cxDf";
                if (string.IsNullOrEmpty(apiKey))
                {
                    throw new Exception("A key should be provided to invoke the endpoint");
                }
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", apiKey);
                client.BaseAddress = new Uri("http://9677ccee-1b55-4b6c-ac9c-8325f1db841c.westeurope.azurecontainer.io/score");

                var content = new StringContent(requestBody, Encoding.UTF8, "application/json");

                HttpResponseMessage response = await client.PostAsync("", content);

                if (response.IsSuccessStatusCode)
                {
                    string result = await response.Content.ReadAsStringAsync();
                    
                    Console.WriteLine("\nRaw JSON Response:");
                    Console.WriteLine(result);  // Print the full response for debugging

                    PrintProbabilities(result);
                }
                else
                {
                    Console.WriteLine($"The request failed with status code: {response.StatusCode}");
                    Console.WriteLine(response.Headers.ToString());

                    string responseContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(responseContent);
                }
            }
        }

        static void PrintProbabilities(string jsonResponse)
        {
            try
            {
                JObject json = JObject.Parse(jsonResponse);

                // Navigate to "Results" -> "WebServiceOutput0"
                var predictions = json["Results"]?["WebServiceOutput0"] as JArray;
                if (predictions == null || predictions.Count == 0)
                {
                    Console.WriteLine("Error: No prediction results found.");
                    return;
                }

                JObject prediction = (JObject)predictions[0];

                // Print all scored probabilities
                foreach (var property in prediction.Properties())
                {
                    string propName = property.Name;
                    if (propName.StartsWith("Scored Probabilities_") || propName == "Scored Labels")
                    {
                        Console.WriteLine($"{propName}: {property.Value}");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error parsing response: " + ex.Message);
            }
        }
    }
}
