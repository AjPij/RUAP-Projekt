import urllib.request
import json
import os
import ssl
import base64
import tkinter as tk
from tkinter import filedialog, messagebox

def allowSelfSignedHttps(allowed):
    if allowed and not os.environ.get('PYTHONHTTPSVERIFY', '') and getattr(ssl, '_create_unverified_context', None):
        ssl._create_default_https_context = ssl._create_unverified_context

allowSelfSignedHttps(True)

def select_image():
    file_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg")])
    if file_path:
        entry_path.delete(0, tk.END)
        entry_path.insert(0, file_path)

def send_request():
    img_path = entry_path.get()
    if not img_path:
        messagebox.showerror("Error", "Please select an image file.")
        return
    
    try:
        with open(img_path, "rb") as image_file:
            base64Image = base64.b64encode(image_file.read()).decode("utf-8")

        data = {
            "Inputs": {
                "WebServiceInput0": [
                    {
                        "image": base64Image,
                        "id": 6,
                        "category": "cap"
                    }
                ]
            },
            "GlobalParameters": {}
        }

        body = str.encode(json.dumps(data))
        url = 'http://9677ccee-1b55-4b6c-ac9c-8325f1db841c.westeurope.azurecontainer.io/score'
        api_key = 'SLgwCGTO1bNo88EI4ytYofAj7pN1cxDf'

        if not api_key:
            raise Exception("A key should be provided to invoke the endpoint")

        headers = {'Content-Type': 'application/json', 'Authorization': 'Bearer ' + api_key}
        req = urllib.request.Request(url, body, headers)
        
        response = urllib.request.urlopen(req)
        result = json.loads(response.read().decode("utf-8"))
        
        print("API Response:", json.dumps(result, indent=4))  # Debugging print
        
        scores = result.get("Results", {}).get("WebServiceOutput0", [])
        
        if not scores or not isinstance(scores, list) or len(scores) == 0:
            messagebox.showerror("Error", "No valid scores returned from the API.")
            return
        
        scores = scores[0] if isinstance(scores[0], dict) else {}
        
        labels = [
            "Ammeter", "ac_src", "battery", "cap", "curr_src", "dc_volt_src_1", "dc_volt_src_2",
            "dep_curr_src", "dep_volt", "diode", "gnd_1", "gnd_2", "inductor", "resistor", "voltmeter"
        ]
        
        formatted_scores = {label: float(scores.get(f"Scored Probabilities_{label}", 0)) for label in labels}
        
        if not formatted_scores:
            messagebox.showerror("Error", "No scores available in API response.")
            return
        
        best_label = max(formatted_scores, key=formatted_scores.get, default="N/A")
        best_score = formatted_scores.get(best_label, 0)
        
        result_text = "\n".join([f"Scored Probability {label}: {formatted_scores[label]:.6f}" for label in labels])
        result_text += f"\n\nBest score: {best_score:.6f} ({best_label})"
        
        lbl_result.config(text=result_text)
    
    except urllib.error.HTTPError as error:
        messagebox.showerror("Request Failed", f"Status code: {error.code}\n{error.read().decode('utf8', 'ignore')}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# gui
root = tk.Tk()
root.title("Simple image scoring console app")
root.geometry("500x400")

frame = tk.Frame(root)
frame.pack(pady=20)

entry_path = tk.Entry(frame, width=40)
entry_path.pack(side=tk.LEFT, padx=5)

btn_browse = tk.Button(frame, text="Browse", command=select_image)
btn_browse.pack(side=tk.LEFT)

btn_submit = tk.Button(root, text="Send Request", command=send_request)
btn_submit.pack(pady=10)

lbl_result = tk.Label(root, text="Scores:", justify=tk.LEFT, anchor="w")
lbl_result.pack(padx=10, pady=10, fill=tk.BOTH)

root.mainloop()
